# Installing Webfonts
Follow these simple Steps.

## 1.
Put `archivo/` Folder into a Folder called `fonts/`.

## 2.
Put `archivo.css` into your `css/` Folder.

## 3. (Optional)
You may adapt the `url('path')` in `archivo.css` depends on your Website Filesystem.

## 4.
Import `archivo.css` at the top of you main Stylesheet.

```
@import url('archivo.css');
```

## 5.
You are now ready to use the following Rules in your CSS to specify each Font Style:
```
font-family: Archivo-Regular;
font-family: Archivo-Medium;
font-family: Archivo-SemiBold;
font-family: Archivo-Bold;

```

